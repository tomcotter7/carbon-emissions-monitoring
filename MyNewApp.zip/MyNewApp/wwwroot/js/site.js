﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
// Use React or Angular
// Monitor certain processes
// Tag identification to trend (difficult)
// Data updadtes quickly, daily -> minute by minute
// display data in a number format, estimate too
// flaring - methane, gas as fuel - co2, diesel - co2
// measure electricity
// numbers similar between fuel and electricity generated
// machine learning for identification of data
// Ithica data

function loadDataSources(pUrl, pDataSourceName) {
    // See the DataSourceController for more on this
    $.ajax(
        {
            url: pUrl,
            type: "GET",
            data: {
                name: pDataSourceName
            },
            traditional: true,
            async: true,
            dataType: "json"
        }
    ).done(function (value) {

    });
}

function loadTags() {

}

function loadDataInInterval(pUrl, pPoints, pTag, pDataSource, pStartTime, pEndTime) {
    $.ajax( // The .ajax() function basically calls a query
        {
            url: pUrl, // URL of the function in TestController, in the format "api/[Name without Controller on the end ie. Test]/[String in Route, specified above function]
            type: "GET", // Specifying that we're trying to get the data
            data: { // A javascript dictionary (get familiar with these, we'll use them in future)
                points: pPoints, // number of points of data we'll get, in this case 1000
                tagNames: [pTag], // only get data from tags in this list; we'll make it inputted by the user at some point
                dataSourceName: pDataSource, // where we're getting the data from
                startTime: pStartTime, // start time of the data, in this case just default constructor for a test. Will eventually be inputted by the user.
                endTime: pEndTime // as above
            },
            // These three aren't that important to understand; just know that you need them
            traditional: true,
            async: true,
            dataType: "json"
        }
    ).done(function (values) {
        console.log(values);
    });
}

function getCurrentDataSource() {
    var DataSourceName = document.getElementById("DataSourceName");
    return DataSourceName.value;
}

/* A little lesson in JavaScript:
 * Since JavaScript is a funky language, functions can
 * be stored as variables like so:
 * 
 * var sayHello = function (name) {
 *      console.log("Hello " + name);
 * }
 * 
 * A dictionary in JavaScript can be made up of a bunch of variables,
 * as such it logically follows that these variables can store functions.
 * Therefore below, I've used the dictionary globalData to store utility functions
 * on the data, almost like a namespace or package.
 * 
 * If you write a bunch of functions relevant to each other,
 * it would certainly help organisation to store them as a dictionary.
 * - Jacques
 */
var globalData =
{
    getSize: function () {
        return window.GlobalData.length;
    },

    getPoint: function (index) {
        return window.GlobalData[index];
    },

    mappedData: {},

    mapData: function () {
        var data = window.GlobalData.map(function (v) {
            return {
                x: new Date(v.utcSampleTime),
                y: v.numericValue
            };
        });

        return data;
    },

    getXPoint: function (index) {
        return globalData.mappedData[index].x;
    },

    getYPoint: function (index) {
        return globalData.mappedData[index].y;
    },

    basicGradient: function (indexA, indexB) {
        var deltaX = indexB - indexA;
        var deltaY = globalData.getYPoint(indexB) - globalData.getYPoint(indexA);

        return deltaY / deltaX;
    },

    meanGradient: function (indexA, indexB) {
        var size = indexB - indexA;
        var total = 0;

        var current = indexA;
        var next = indexA + 1;
        while (next <= indexB) {
            total += globalData.basicGradient(current, next);
            current += 1;
            next += 1;
        }

        return total / size;
    }
};

function testClick() {

    //loadDataInInterval("api/Test/values", 1000, "antifoam inj pump a_pi", "IP Datasource 2", new Date().toISOString(), new Date().toISOString());
    var now = new Date();
    var yesterday = new Date(now.getTime());
    //yesterday.setDate(now.getDate() - 1);

    loadDataInInterval("api/Test/values", 1000, window.SelectedTag, getCurrentDataSource(), now.toISOString(), yesterday.toISOString());

    /*globalData.mappedData = globalData.mapData();
    for (var i = 0; i < globalData.getSize(); i++) {
        console.log(globalData.getXPoint(i) + ": " + globalData.getYPoint(i));
    }

    console.log(globalData.basicGradient(0, 1) + ", " + globalData.meanGradient(0, 50));*/

    //for (var i = 0; i < globalData.getSize(); i++) {
    //    console.log(globalData.getPoint(i));
    //}
}
